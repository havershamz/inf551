import json

from bottle import route, run, template


@route('/hello/<kwd>')
def index(kwd):

    # firebase

    musics = [{"name": "test"}]

    data = []
    for music in musics:
        if kwd in music['name']:
            data.append(music)
    print(data)
    return template("index.html", data=data)


run(host='localhost', port=8080)